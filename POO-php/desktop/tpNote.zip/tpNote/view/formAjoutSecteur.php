<form action="index.php?page=doAjoutSecteur" method="post">
    <label for="libelleSec">Libelle Secteur</label>
    <input type="text" name="libelleSec" id="libelleSec">
    <input type="submit" value="valider">
</form>