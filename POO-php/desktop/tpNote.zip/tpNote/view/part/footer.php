</body>
<footer>
    &copy; Portier Quentin
    <p>
        <a href="index.php?page=viewStructures">Liste des structures</a><br/>
        <a href="index.php?page=viewSecteurs">Liste des secteurs</a><br/>
    </p>
</footer>